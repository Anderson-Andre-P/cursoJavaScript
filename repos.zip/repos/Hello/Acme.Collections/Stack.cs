﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Acme.Collections
{
    public class Stack
    {
        Entry top;

        /// <summary>

        /// Metodo para insercao no topo da pilha

        /// </summary>

        /// <param name="data">objeto que gostaria de emplihar</param>

        public void Push(object data)

        {

            top = new Entry(top, data);

        }



        /// <summary>

        /// Metodo para remover do topo da pilha

        /// </summary>

        /// <returns>Objeto topo da pilha</returns>

        public object Pop()

        {

            if (top == null) throw new InvalidOperationException();



            object result = top.data;

            top = top.next;



            return result;

        }



        public class Entry

        {

            public Entry next;

            public object data;



            public Entry(Entry next, object data)

            {

                this.next = next;

                this.data = data;

            }

        }

    }



}

